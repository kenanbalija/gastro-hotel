<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SuperiorRoom extends Model
{
  protected $table= 'superiorRooms';
  protected $fillable = [
    'img'
  ];
}
