<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Text extends Model
{
    //
    protected $fillable = ['about_tekst' , 'about_tekst_sub','about_tekst_en' , 'about_tekst_sub_en'];
}
