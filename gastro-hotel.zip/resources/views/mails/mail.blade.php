Dobili ste upit za novu rezervaciju!<br/><br/>

<b>Ime</b>: <em> {{ $name }}</em><br/>
<b>Prezime</b>: <em> {{ $lastname }}</em><br/>
<b>Email</b>: <em> {{ $email }}</em><br/>
<b>Telefon</b>: <em> {{ $phone }}</em><br/>
<b>Datum Prijave</b>:<em> {{ $checkin }}</em><br/>
<b>Datum Odjave</b>: <em> {{ $checkout }}</em><br/>
<b>Vrsta Sobe</b>: <em> {{ $room }}</em><br/><br/>

Molimo potvrdite prijavu na broj: {{ $phone }} ili email: {{ $email }}
