@extends('layouts.app')

@section('content')
@include('navigations.navigationEN')

<section id="extra-bg">
</section>
@endsection
@section('showcase')
<section id="welcome">
  <h1 style="text-align:center; font-size:60px; color:rgb(152,134,113);">THIS PART OF PAGE IS COMING SOON!!</h1>


</section>t
@endsection
