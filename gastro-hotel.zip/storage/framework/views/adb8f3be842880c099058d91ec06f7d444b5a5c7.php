<?php $__env->startSection('content'); ?>
<?php echo $__env->make('navigations.navigationBA', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section id="extra-bg">
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('showcase'); ?>
  <div class="editForm container">
    <?php foreach($texts as $text): ?>
        <form id="" role="form" method="POST" action="<?php echo e(url('/services/saveOffer', $text->id)); ?>" enctype="multipart/form-data">
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <h4>Skijanje:</h4>
          <textarea  name="ski" rows="10" cols="100"><?php echo $text->ski; ?></textarea>
          <h4>Skijanje Eng:</h4>
          <textarea  name="skiEn" rows="10" cols="100"><?php echo $text->skiEn; ?></textarea>
          <h4>Golf:</h4>
          <textarea  name="golf" rows="10" cols="100"><?php echo $text->golf; ?></textarea>
          <h4>Golf Eng:</h4>
          <textarea  name="golfEn" rows="10" cols="100"><?php echo $text->golfEn; ?></textarea>
          <h4>Jahanje:</h4>
          <textarea  name="ride" rows="10" cols="100"><?php echo $text->ride; ?></textarea>
          <h4>Jahanje Eng:</h4>
          <textarea  name="rideEn" rows="10" cols="100"><?php echo $text->rideEn; ?></textarea>
          <h4>Rafting:</h4>
          <textarea  name="raft" rows="10" cols="100"><?php echo $text->raft; ?></textarea>
          <h4>Rafting Eng:</h4>
          <textarea  name="raftEn" rows="10" cols="100"><?php echo $text->raftEn; ?></textarea>
          <br/>
          <br/>

        <input class="btn btn-success" type="submit" value="UPDATE">
        </form>
        <br/>

    <?php endforeach; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>