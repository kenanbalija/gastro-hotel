<?php $__env->startSection('content'); ?>
<section id="extra-bg">
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('showcase'); ?>
<section id="news">
  <h3>NEWS</h3><span class="vertical-line">|</span><span>UT WISI ENIM AD MINIM VEN</span>
  <div class="row">
    <article class="col-xs-12">
      <section class="news-img" class="col-xs-12" >
      </section>
      <div class="news-date col-xs-12 col-md-2 "><span>02</span><span>05</span><span>16</span></div>
      <div class="news-news col-xs-12 col-md-10">
        <h4>CLARITAS EST</h4>
          <div class="news-text">Wecer possim assum. Typi non hbent claritatem</div>
      </div>
    </article>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>