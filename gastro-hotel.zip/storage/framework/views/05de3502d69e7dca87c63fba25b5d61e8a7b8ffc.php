<?php $__env->startSection('content'); ?>
<?php echo $__env->make('navigations.navigationBA', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section id="extra-bg">
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('showcase'); ?>
  <div class="editForm container">
    <?php foreach($events as $event): ?>
        <form id="eventsForm" role="form" method="POST" action="<?php echo e(url('/events/save', $event->id)); ?>" enctype="multipart/form-data">
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <textarea  name="meeting" rows="10" cols="100"><?php echo $event->meetings; ?></textarea>
          <textarea  name="meetingEn" rows="10" cols="100"><?php echo $event->meetingsEn; ?></textarea>
          <textarea  name="service" rows="10" cols="100"><?php echo $event->services; ?></textarea>
          <textarea  name="serviceEn" rows="10" cols="100"><?php echo $event->servicesEn; ?></textarea>
        <input class="btn btn-success" type="submit" value="UPDATE">
        </form>
    <?php endforeach; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>