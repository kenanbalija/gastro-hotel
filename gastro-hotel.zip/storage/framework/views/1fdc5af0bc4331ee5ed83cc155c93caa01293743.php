<?php $__env->startSection('content'); ?>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
  <?php foreach($albums as $album): ?>

    <span>Create New Album</span>
    <div class="container" style="text-align: center;">
      <div class="span4" style="display: inline-block;margin-top:100px;">

    <?php if($errors->has()): ?>
      <div class="alert alert-block alert-error fade in"id="error-block">
         <?php
         $messages = $errors->all('<li>:message</li>');
        ?>
        <button type="button" class="close"data-dismiss="alert">×</button>

        <h4>Warning!</h4>
        <ul>
          <?php foreach($messages as $message): ?>
            <?php echo e($message); ?>

          <?php endforeach; ?>

        </ul>
      </div>
    <?php endif; ?>

    <form name="createnewalbum" method="POST"action="<?php echo e(URL::route('create_album')); ?>"enctype="multipart/form-data">
      <fieldset>
        <legend>Create an Album</legend>
        <div class="form-group">
          <label for="name">Album Name</label>
          <input name="name" type="text" class="form-control"placeholder="Album Name"value="<?php echo e(Input::old('name')); ?>">
        </div>
        <div class="form-group">
          <label for="description">Album Description</label>
          <textarea name="description" type="text"class="form-control" placeholder="Albumdescription"><?php echo e(Input::old('descrption')); ?></textarea>
        </div>
        <div class="form-group">
          <label for="cover_image">Select a Cover Image</label>
          <?php echo e(Form::file('cover_image')); ?>

        </div>
        <button type="submit" class="btnbtn-default">Create!</button>
      </fieldset>
    </form>
  </div>
</div> <!-- /container -->
<?php endforeach; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>