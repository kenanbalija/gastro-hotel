<?php $__env->startSection('content'); ?>
<?php echo $__env->make('navigations.navigationBA', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <section id="extra-bg">
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('showcase'); ?>
<section id="photos">
  <h3>ALBUMI</h3>
  <div class="row">
    <div class="col-xs-12 col-sm-4">
      <span>Apartmani i sobe</span>
      <a href="<?php echo e(url('/photos/apartmants')); ?>"><div id="oneAlbum"></div></a>
    </div>
    <div class="col-xs-12 col-sm-4">
      <span>Restoran I i II</span>
      <a href="<?php echo e(url('/photos/restaurants')); ?>"><div id="twoAlbum"></div></a>
    </div>
    <div class="col-xs-12 col-sm-4">
      <span>Glavni i popratni objekat</span>
      <a href="<?php echo e(url('/photos/exterior')); ?>"><div id="thrAlbum"></div></a>
    </div>
    <!-- <section class="col-xs-12">
      <img src="<?php echo e(asset('img/rooms-apartmants.jpg')); ?>">
        <h5 class="col-xs-12 hidden-text">Sobe i apartmani / Rooms and apartments </h5>
    </section>
    <section class="col-xs-12">
      <img src="<?php echo e(asset('img/restaurant-terrace.jpg')); ?>">
      <h5 class="col-xs-12 hidden-text">Restoran I i II, terasa/ Restaurant I & II and terrace </h5>
    </section>
    <section class="col-xs-12">
      <img src="<?php echo e(asset('img/hotel-surrounding.jpg')); ?>">
      <h5 class="col-xs-12 hidden-text">Eksterijer glavnog i popratnog objekta, Hotel surrounding</h5>
    </section> -->

  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>