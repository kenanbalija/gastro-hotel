<?php $__env->startSection('content'); ?>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<?php foreach($albums as $album): ?>

<container>
              <img alt="<?php echo e($album->name); ?>" src="/albums/<?php echo e($album->cover_image); ?>">
                 <h3><?php echo e($album->name); ?></h3>
                 <p><?php echo e($album->description); ?></p>
                 <p><?php echo e(count($album->Photos)); ?> image(s).</p>
                 <p>Created date:  <?php echo e(date("d F Y",strtotime($album->created_at))); ?> at <?php echo e(date("g:ha",strtotime($album->created_at))); ?></p>
                 <p><a href="<?php echo e(URL::route('show_album',array('id'=>$album->id))); ?>" class="btn btn-big btn-default">Show Gallery</a></p>
               </container>
         <?php endforeach; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>