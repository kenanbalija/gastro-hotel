<?php $__env->startSection('content'); ?>
<?php echo $__env->make('navigations.navigationBA', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section id="extra-bg">
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('showcase'); ?>
<!-- <?php if(Auth::user()): ?>
  <a class="editStuff" href="<?php echo e(url('events/edit/1')); ?>"><div>EDIT</div></a>
<?php endif; ?> -->
<section id="news">

  <h3>SASTANCI I DOGADAJI</h3>
  <div class="row">
    <article id="events" class="col-xs-12">
      <div>
        <!-- U mogućnosti ste organizovati sve vrste sastanaka i zabavnih događaja
        privatnog i poslovnog karaktera pri čemu vam osoblje
        hotela stoji na raspolaganju da vam pruži kvalitetnu uslugu i vrhunski provod. -->
        <?php foreach($events as $event): ?>
          <?php echo $event->meetings; ?>

        <?php endforeach; ?>
        <ul class="row">
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/signs.png')); ?>">
            <a href="<?php echo e(url('/events/weddings')); ?>">Vjenčanja</a>
          </li>
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/team.png')); ?>">
            <a href="<?php echo e(url('/events/teams')); ?>">Team building</a>
          </li>
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/presentation.png')); ?>">
            <a href="<?php echo e(url('/events/conferences')); ?>">Konferencijska Sala</a>
          </li>
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/food.png')); ?>">
            <a href="<?php echo e(url('/events/birthdays')); ?>">Rođendani i ostale zabave</a>
          </li>
        </ul>
      </div>
    </article>
  </div>
  <?php if(Auth::user()): ?>

  <div>
  <a href="<?php echo e(url('/events/edit/1')); ?>" class="btn btn-danger" >
    EDIT
  </a>
  </div>
  <?php endif; ?>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('showcase-two'); ?>
<section id="news">
  <h3>USLUGE ZA GOSTE</h3>
  <div class="row">
    <article id="guest-services" class="col-xs-12">
      <div>
        <!-- Hotel nudi organizaciju izleta za što se možete obratiti
        hotelskom osoblju za više informacija pri čemu će Vam rado
        pomoći da ponudu prilagodite Vasim potrebama.<br/>
        Molim Vas kontaktirajte nas na hotel@gastroid.ba ili telefon +387 33 770-600 -->
        <?php foreach($events as $event): ?>
          <?php echo $event->services; ?>

        <?php endforeach; ?>
        <ul class="row">
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/sports.png')); ?>">
            <a href="<?php echo e(url('/services/skiing')); ?>">Skijanje</a>
          </li>
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/ball.png')); ?>">
            <a href="<?php echo e(url('/services/golfing')); ?>">Golf</a>
          </li>
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/saddle.png')); ?>">
            <a href="<?php echo e(url('/services/riding')); ?>">Jahanje</a>
          </li>
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/canoe.png')); ?>">
            <a href="<?php echo e(url('/services/rafting')); ?>">Rafting</a>
          </li>
        </ul>
      </div>
    </article>
  </div>
  <?php if(Auth::user()): ?>

  <div>
  <a href="<?php echo e(url('/events/edit/1')); ?>" class="btn btn-danger" >
    EDIT
  </a>
  </div>
  <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>