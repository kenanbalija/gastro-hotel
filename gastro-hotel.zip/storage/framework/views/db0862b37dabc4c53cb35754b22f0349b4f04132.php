<!-- 

<?php $__env->startSection('content'); ?>
<section id="extra-bg">
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('showcase'); ?>
<section id="news">
  <h3>USLUGE ZA GOSTE</h3>
  <div class="row">
    <article id="guest-services" class="col-xs-12">
      <h4>Prijevoz sa i do aerodroma</h4>
      <h4>Organizacija izleta</h4>
      <div>
        Hotel nudi organizaciju izleta za što se možete obratiti
        hotelskom osoblju za više informacija pri čemu će Vam rado
        pomoći da ponudu prilagodite Vasim potrebama.<br/>
        Molim Vas kontaktirajte nas na hotel@gastroid.ba ili telefon +387 33 770-600
        <ul class="row">
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/sports.png')); ?>">
            <a href="<?php echo e(url('/services/skiing')); ?>">Skijanje</a>
          </li>
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/ball.png')); ?>">
            <a href="<?php echo e(url('/services/golfing')); ?>">Golf</a>
          </li>
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/saddle.png')); ?>">
            <a href="<?php echo e(url('/services/riding')); ?>">Jahanje</a>
          </li>
          <li class="col-xs-12 col-sm-6 ">
            <img style="width: 32px;" src="<?php echo e(asset('img/icons/canoe.png')); ?>">
            <a href="<?php echo e(url('/services/rafting')); ?>">Rafting</a>
          </li>
        </ul>
      </div>
    </article>
  </div>
</section>

<?php $__env->stopSection(); ?> -->

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>