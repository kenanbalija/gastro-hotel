Dobili ste upit za novu rezervaciju!<br/><br/>

<b>Ime</b>: <em> <?php echo e($name); ?></em><br/>
<b>Prezime</b>: <em> <?php echo e($lastname); ?></em><br/>
<b>Email</b>: <em> <?php echo e($email); ?></em><br/>
<b>Telefon</b>: <em> <?php echo e($phone); ?></em><br/>
<b>Datum Prijave</b>:<em> <?php echo e($checkin); ?></em><br/>
<b>Datum Odjave</b>: <em> <?php echo e($checkout); ?></em><br/>
<b>Vrsta Sobe</b>: <em> <?php echo e($room); ?></em><br/><br/>

Molimo potvrdite prijavu na broj: <?php echo e($phone); ?> ili email: <?php echo e($email); ?>

