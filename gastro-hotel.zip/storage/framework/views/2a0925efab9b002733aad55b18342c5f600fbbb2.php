<?php $__env->startSection('content'); ?>
<?php echo $__env->make('navigations.navigationBA', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section id="extra-bg">
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('showcase'); ?>
<section id="welcome">
  <h1 style="text-align:center; font-size:60px; color:rgb(152,134,113);">THIS PART OF PAGE IS COMING SOON!!</h1>


</section>t
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>