<?php $__env->startSection('content'); ?>
<?php echo $__env->make('navigations.navigationBA', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section id="extra-bg">
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('showcase'); ?>
  <div class="addImage container">
    <form class="" role="form" method="POST" action="<?php echo e(url('/rooms/superior/save')); ?>" enctype="multipart/form-data">

      Image:<input type="file" name="img"><br/>
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <input class="btn btn-success" type="submit" value="Submit">

    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>