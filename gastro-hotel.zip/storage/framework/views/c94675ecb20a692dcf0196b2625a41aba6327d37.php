<div id="small-nav" class="navbar-fixed-top"  onclick="openNav()">
  <img src="<?php echo e(asset('img/gh-logo.png')); ?>">
  <span>&#9776; Home</span>
</div>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <a href="<?php echo e(url('/')); ?>">Početna</a>
    <a href="<?php echo e(url('/rooms')); ?>">Sobe</a>
    <a href="<?php echo e(url('/photos')); ?>">Fotografije</a>
    <a href="<?php echo e(url('/events')); ?>">Dešavanja i Usluge</a>
    <!-- <a href="<?php echo e(url('/services')); ?>">Usluge</a> -->
    <a href="<?php echo e(url('/contact')); ?>">Kontakt</a>

</div>
<nav class="navbar navbar-default navbar-fixed-top">
  <div>
    <div class="container" id="nav-container">
      <section id="navigation-links">
          <div class="navbar-header">

              <!-- Branding Image -->
              <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                  <img class="brand-img" src=" <?php echo e(asset('img/gastro-natpis-logo-white.png')); ?>">
              </a>
              <div class="navbar-brand-border"></div>
          </div>

          <div class="collapse navbar-collapse" id="app-navbar-collapse">
              <!-- Left Side Of Navbar -->
              <ul class="nav navbar-nav row">
                  <li class="dropdown">
                    <a href="<?php echo e(url('/home')); ?>">
                      <button type="button" value="hide/show" class="homeButton" >Početna</button><span class="caret"></span>
                    </a>
                  </li>
                  <li><a href="<?php echo e(url('/rooms')); ?>">Sobe</a></li>
                  <li><a href="<?php echo e(url('/photos')); ?>">Fotografije</a></li>
                  <li><a href="<?php echo e(url('/events')); ?>">Dešavanja i Usluge</a></li>
                  <!-- <li><a href="<?php echo e(url('/services')); ?>">Usluge</a></li> -->
                  <li><a href="<?php echo e(url('/contact')); ?>">Kontakt</a></li>
              </ul>

              <!-- Right Side Of Navbar -->
              <ul class="nav navbar-nav navbar-right">
                <li><a><button type="button" value="hide/show" class="searchButton" ><img src="<?php echo e(asset('img/icons/search-13.ico')); ?>"></button></a></li>
                  <!-- Authentication Links -->
                  <?php if(Auth::guest()): ?>
                      <li><a href="<?php echo e(url('/login')); ?>"><img class="padlock-img" src="<?php echo e(asset('img/icons/padlock.ico')); ?>"></a></li>
                  <?php else: ?>
                      <li class="dropdown">
                          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <img class="padlock-img" src="<?php echo e(asset('img/icons/padlock.ico')); ?>">
                          </a>

                          <ul class="dropdown-menu" role="menu">
                              <li id="no-border"><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>logout</a></li>
                          </ul>
                      </li>
                  <?php endif; ?>
              </ul>
          </div>
      </section>
    </div>
  </div>
    <div id="searchContainer" class="container">
      <div id="searchDiv">
        <div class="row">
          <span class="col-xs-1">Search</span>
          <input class="col-xs-7" type="text" placeholder="enter word">
          <button class="col-xs-2 btn btn-success">search</button>
        </div>
      </div>
    </div>
    <div id="aboutContainer"  class="container">
      <div id="aboutDiv">
        <div class="row">
          <div class="col-xs-3">
            <a href="<?php echo e(url('/home')); ?>#welcome">O Hotelu</a>
          </div>
          <div class="col-xs-3">
            <a href="<?php echo e(url('/home')); ?>#booking">Rezervacija</a>
          </div>
          <div class="col-xs-3">
            <a href="<?php echo e(url('/home')); ?>#connect-us">Povežimo se</a>
          </div>
          <div class="col-xs-3">
            <a href="<?php echo e(url('/home')); ?>#news">Sadržaj</a>
          </div>
        </div>
      </div>
    </div>
</nav>
