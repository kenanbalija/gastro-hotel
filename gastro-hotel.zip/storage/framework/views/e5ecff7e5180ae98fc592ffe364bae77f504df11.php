<?php $__env->startSection('content'); ?>
<?php echo $__env->make('navigations.navigationBA', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section id="extra-bg">
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('showcase'); ?>
  <div class="editForm container">
    <?php foreach($texts as $text): ?>
        <form id="" role="form" method="POST" action="<?php echo e(url('/events/saveOffer', $text->id)); ?>" enctype="multipart/form-data">
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <h4>Vjenčanje:</h4>
          <textarea  name="wedding" rows="10" cols="100"><?php echo $text->wedding; ?></textarea>
          <h4>Vjenčanje Eng:</h4>
          <textarea  name="weddingEn" rows="10" cols="100"><?php echo $text->weddingEn; ?></textarea>
          <h4>Team Building:</h4>
          <textarea  name="teambuilding" rows="10" cols="100"><?php echo $text->teambuilding; ?></textarea>
          <h4>Team Building Eng:</h4>
          <textarea  name="teambuildingEn" rows="10" cols="100"><?php echo $text->teambuildingEn; ?></textarea>
          <h4>Konferencije:</h4>
          <textarea  name="conference" rows="10" cols="100"><?php echo $text->conference; ?></textarea>
          <h4>Konferencije Eng:</h4>
          <textarea  name="conferenceEn" rows="10" cols="100"><?php echo $text->conferenceEn; ?></textarea>
          <h4>Rođendani:</h4>
          <textarea  name="birthday" rows="10" cols="100"><?php echo $text->birthday; ?></textarea>
          <h4>Rođendani Eng:</h4>
          <textarea  name="birthdayEn" rows="10" cols="100"><?php echo $text->birthdayEn; ?></textarea>
          <br/>
          <br/>
        <input class="btn btn-success" type="submit" value="UPDATE">
        </form>
        <br/>

    <?php endforeach; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>