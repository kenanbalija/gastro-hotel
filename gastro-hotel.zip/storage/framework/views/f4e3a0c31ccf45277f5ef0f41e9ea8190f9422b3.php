<?php $__env->startSection('content'); ?>
<?php echo $__env->make('navigations.navigationBA', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section id="extra-bg">
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('showcase'); ?>
<section id="news">
  <h3>KONFERENCIJSKA SALA</h3>
  <div class="row">
    <?php if(Auth::user()): ?>
      <div>
      <a href="<?php echo e(url('/events/editOffer/1')); ?>" class="btn btn-danger" >
        EDIT
      </a>
      </div>
    <?php endif; ?>
    <article id="events" class="col-xs-12">
      <?php foreach($texts as $text): ?>
        <?php echo $text->conference; ?>

      <?php endforeach; ?>
      <!-- <p>
        Hotel by GastroID nudi mogućnost organizacije svih vsta sastanaka u
        konferencijskoj sali koja stoji na raspolaganju gostima i posjetiocima hotela.
      </p>
      <p>
        Konferencijska sala je kapaciteta 25-30 sjedećih mjesta, te sadrži projektor
        i platno. Prostorija je zatvorenog tipa, te Vam je omogućena potpuna privatnost.
        A ukoliko želite organizovati ručak ili večeru, hotelski restoran
        Vam stoji na raspolaganju. Takođe, pauze od sastanaka možete provesti
        u hotelskom caffe-u.
      </p>
      <p>
        Cijena najma konferencijske sale zavisi o vremenskom periodu, te o potrebi
         za organizacijom ručka ili večere stoga zvaničnu ponudu možete dobiti nakon razgovora s hotelskim osobljem.
      </p>
      <p>
        Za više informacija, molimo Vas da kontaktirate hotel na e-mail hotel@gastroid.ba ili kontakt telefon 033 770-600.
      </p> -->
    </article>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>